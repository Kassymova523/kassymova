package com.company;

import com.company.model.database.IDB;
import com.company.model.database.PostgresDB;
import com.company.model.repository.ISystemRepository;
import com.company.model.repository.IUserRepository;
import com.company.model.repository.SystemRepository;
import com.company.model.repository.UserRepository;
import com.company.view.Application;

public class Main {

    public static void main(String[] args) {

        IDB db = new PostgresDB();

        ISystemRepository systemRepository = new SystemRepository(db);

        IUserRepository userRepository = new UserRepository(db);

        Application app = new Application(systemRepository, userRepository);
        app.start();
    }
}
