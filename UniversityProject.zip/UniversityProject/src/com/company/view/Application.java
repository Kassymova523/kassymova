package com.company.view;

import com.company.controller.SystemController;
import com.company.controller.UserController;
import com.company.model.entities.Flight;
import com.company.model.repository.ISystemRepository;
import com.company.model.repository.IUserRepository;

import java.util.ArrayList;
import java.util.Scanner;

public class Application {

    private SystemController systemController;
    private UserController userController;

    public Application(ISystemRepository systemRepository, IUserRepository userRepository){
        systemController = new SystemController(systemRepository);
        userController = new UserController(userRepository);
    }

    public void start(){

        Scanner in = new Scanner(System.in);
        System.out.println("Welcome to our avia company");

        while(true) {

            System.out.println("1: I am a worker");
            System.out.println("2: I am a client");

            int v = in.nextInt();

            if (v == 1) {
                System.out.println("1: Show all flights");
                System.out.println("2: Delete flight");

                v = in.nextInt();

                if (v == 1) {
                    showAllFlights();
                } else if (v == 2) {
                    System.out.println("Enter id");
                    int d = in.nextInt();

                    systemController.deleteFlight(d);
                }
            } else if (v == 2) {
                System.out.println("1: Buy a ticket");
                System.out.println("2: Return my ticket");

                int c = in.nextInt();

                if(c == 1){
                    String dest, date, time, iin;
                    System.out.println("Input destination");
                    dest = in.next();
                    System.out.println("Input date");
                    date = in.next();
                    System.out.println("Input time");
                    time = in.next();
                    System.out.println("Input iin");
                    iin = in.next();

                    userController.addNewFlight(new Flight(0, dest, date, time, iin));


                    System.out.println("Congratulations!");
                    System.out.println("-------------------------------");
                    System.out.println("Date: " + date + "    time: " + time);
                    System.out.println(iin);
                    System.out.println("-------------------------------");

                } else if(c == 2){
                    System.out.println("Enter id of flight");
                    int id = in.nextInt();
                    systemController.deleteFlight(id);

                }

            } else {
                System.exit(0);
            }
        }

    }

    void showAllFlights(){
        ArrayList<Flight> fs = systemController.getAllFlights();
        for(Flight f : fs){
            System.out.println(f.toString());
        }
    }




}

