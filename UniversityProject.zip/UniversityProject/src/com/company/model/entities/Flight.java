package com.company.model.entities;

public class Flight {

    private int id;
    private String destination;

    private String date;
    private String time;

    private String iin;


    public Flight(int id, String destination, String date, String time, String iin) {
        this.id = id;
        this.destination = destination;
        this.date = date;
        this.time = time;
        this.iin = iin;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getIin() {
        return iin;
    }

    public void setIin(String iin) {
        this.iin = iin;
    }

    @Override
    public String toString() {
        return "Flight{" +
                "id=" + id +
                ", destination='" + destination + '\'' +
                ", date='" + date + '\'' +
                ", time='" + time + '\'' +
                ", iin='" + iin + '\'' +
                '}';
    }
}
