package com.company.model.repository;

import com.company.model.entities.Flight;

public interface IUserRepository {
    void addNewFlight(Flight flght);
    void deleteMyFlight(Flight flight);

}
