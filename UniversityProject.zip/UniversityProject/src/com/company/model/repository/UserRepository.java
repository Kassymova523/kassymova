package com.company.model.repository;

import com.company.model.database.IDB;
import com.company.model.entities.Flight;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserRepository implements IUserRepository{

    private final IDB db;

    public UserRepository(IDB db) {
        this.db = db;
    }

    public void addNewFlight(Flight flight){
        Connection con = null;


        try {
            con = db.getConnection();
            String sql = "insert into flights values (default, ?, ?, ?, ?)";
            PreparedStatement st = con.prepareStatement(sql);

            st.setString(1, flight.getDestination());
            st.setString(2, flight.getDate());
            st.setString(3, flight.getTime());
            st.setString(4, flight.getIin());

            st.execute();



        } catch (Exception e){
            System.out.println(e);
        } finally {
            try {
                con.close();
            } catch (Exception e){
                System.out.println(e);
            }
        }
    }
    public void deleteMyFlight(Flight flight){

    }
}
