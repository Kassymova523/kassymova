package com.company.model.repository;

import com.company.model.entities.Flight;

import java.util.ArrayList;

public interface ISystemRepository {

    ArrayList<Flight> getAllFlights();

    void deleteFlight(int id);
}
