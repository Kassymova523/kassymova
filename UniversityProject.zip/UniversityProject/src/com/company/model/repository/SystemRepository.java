package com.company.model.repository;

import com.company.model.database.IDB;
import com.company.model.entities.Flight;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class SystemRepository implements ISystemRepository{

    private final IDB db;

    public SystemRepository(IDB db) {
        this.db = db;
    }

    public ArrayList<Flight> getAllFlights(){
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;

        ArrayList<Flight> res = new ArrayList<>();

        try {

            con = db.getConnection();
            st = con.createStatement();
            rs = st.executeQuery("select * from flights");

            while(rs.next()){
                if(rs.getInt(1) != -1) {
                    res.add(new Flight(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)));
                }
            }

            return res;

        } catch (Exception e){
            System.out.println(e);
        } finally {
            try {
                con.close();
            } catch (Exception e){
                System.out.println(e);
            }
        }

        return null;
    }


    public void deleteFlight(int id){
        Connection con = null;
        ResultSet rs = null;


        try {

            con = db.getConnection();
            String sql = "update flights set id=-1";
            PreparedStatement st = con.prepareStatement(sql);

            st.execute();


        } catch (Exception e){
            System.out.println(e);
        } finally {
            try {
                con.close();
            } catch (Exception e){
                System.out.println(e);
            }
        }
    }
}
