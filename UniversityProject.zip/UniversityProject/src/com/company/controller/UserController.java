package com.company.controller;

import com.company.model.entities.Flight;
import com.company.model.repository.IUserRepository;
import com.company.model.repository.UserRepository;

public class UserController {

    private final IUserRepository repository;

    public UserController(IUserRepository repository) {
        this.repository = repository;
    }

    public void addNewFlight(Flight flight){
        repository.addNewFlight(flight);
    }
}
