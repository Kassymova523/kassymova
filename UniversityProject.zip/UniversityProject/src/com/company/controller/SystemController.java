package com.company.controller;

import com.company.model.entities.Flight;
import com.company.model.repository.ISystemRepository;
import com.company.model.repository.SystemRepository;

import java.util.ArrayList;

public class SystemController {
    private final ISystemRepository repository;

    public SystemController(ISystemRepository repository) {
        this.repository = repository;
    }

    public ArrayList<Flight> getAllFlights(){
        return repository.getAllFlights();
    }

    public void deleteFlight(int id){
        repository.deleteFlight(id);
    }

}
